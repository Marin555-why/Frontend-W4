import React from "react";
function Header(){
    return(
        <header className="block">
            <h1>Welcome to This Course!</h1>
        </header>
    )
}

export default Header;